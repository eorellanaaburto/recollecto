import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/localization/local_text.dart';
import '../../../core/widgets/app_header.dart';
import '../../items/data/item_repository.dart';
import '../../items/data/photo_storage_service.dart';
import '../../items/domain/models/potential_duplicate_model.dart';
import '../../items/presentation/item_detail_page.dart';

class ImageAnalysisPage extends StatefulWidget {
  const ImageAnalysisPage({super.key});

  @override
  State<ImageAnalysisPage> createState() => _ImageAnalysisPageState();
}

class _ImageAnalysisPageState extends State<ImageAnalysisPage> {
  final PhotoStorageService _photoStorageService = PhotoStorageService();
  final ItemRepository _itemRepository = ItemRepository();

  XFile? _selectedPhoto;
  final List<PotentialDuplicateModel> _matches = [];

  bool _isPreparingHashes = true;
  bool _isAnalyzing = false;

  @override
  void initState() {
    super.initState();
    _prepareHashes();
  }

  Future<void> _prepareHashes() async {
    try {
      await _itemRepository.rebuildAllImageHashes(_photoStorageService);
    } catch (_) {}

    if (!mounted) return;

    setState(() {
      _isPreparingHashes = false;
    });
  }

  Future<void> _pickFromCamera() async {
    if (_isPreparingHashes || _isAnalyzing) return;

    final photo = await _photoStorageService.pickFromCamera();
    if (photo == null || !mounted) return;

    await _analyzePhoto(photo);
  }

  Future<void> _pickFromGallery() async {
    if (_isPreparingHashes || _isAnalyzing) return;

    final photos = await _photoStorageService.pickFromGallery();
    if (photos.isEmpty || !mounted) return;

    await _analyzePhoto(photos.first);
  }

  Future<void> _analyzePhoto(XFile photo) async {
    setState(() {
      _isAnalyzing = true;
      _selectedPhoto = photo;
      _matches.clear();
    });

    try {
      final hashes = await _photoStorageService.computeHashesFromPickedFiles([
        photo,
      ]);

      if (hashes.isEmpty) {
        if (!mounted) return;

        setState(() {
          _isAnalyzing = false;
        });

        _showMessage(
          tr(
            context,
            es: 'No se pudo analizar la imagen seleccionada.',
            en: 'The selected image could not be analyzed.',
          ),
        );
        return;
      }

      final matches = await _itemRepository.findItemsByImageHashes(
        imageHashes: hashes,
      );

      if (!mounted) return;

      setState(() {
        _matches
          ..clear()
          ..addAll(matches);
        _isAnalyzing = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isAnalyzing = false;
      });

      _showMessage(
        tr(
          context,
          es: 'Ocurrió un error al buscar coincidencias.',
          en: 'An error occurred while searching for matches.',
        ),
      );
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isPreparingHashes) {
      return Scaffold(
        appBar: AppHeader(
          title: tr(context, es: 'Análisis de imagen', en: 'Image analysis'),
          subtitle: tr(
            context,
            es: 'Preparando búsqueda visual...',
            en: 'Preparing visual search...',
          ),
          showBackButton: true,
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return Scaffold(
      appBar: AppHeader(
        title: tr(context, es: 'Análisis de imagen', en: 'Image analysis'),
        subtitle: tr(
          context,
          es: 'Toma una foto y revisa si ya existe en tu colección.',
          en: 'Take a photo and check whether it already exists in your collection.',
        ),
        showBackButton: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    tr(context, es: 'Buscar por foto', en: 'Search by photo'),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    tr(
                      context,
                      es: 'Toma una foto del objeto o selecciona una imagen guardada.',
                      en: 'Take a photo of the item or choose a saved image.',
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _isAnalyzing ? null : _pickFromCamera,
                          icon: const Icon(Icons.camera_alt_outlined),
                          label: Text(
                            tr(context, es: 'Cámara', en: 'Camera'),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _isAnalyzing ? null : _pickFromGallery,
                          icon: const Icon(Icons.photo_library_outlined),
                          label: Text(
                            tr(context, es: 'Galería', en: 'Gallery'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (_selectedPhoto != null) ...[
            Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AspectRatio(
                    aspectRatio: 4 / 3,
                    child: Image.file(
                      File(_selectedPhoto!.path),
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Center(
                        child: Icon(Icons.broken_image_outlined, size: 42),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(
                      tr(context,
                          es: 'Foto a comparar', en: 'Photo to compare'),
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],
          if (_isAnalyzing)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const CircularProgressIndicator(),
                    const SizedBox(height: 12),
                    Text(
                      tr(
                        context,
                        es: 'Buscando coincidencias en tu colección...',
                        en: 'Searching for matches in your collection...',
                      ),
                    ),
                  ],
                ),
              ),
            )
          else if (_selectedPhoto != null && _matches.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      tr(
                        context,
                        es: 'No encontramos coincidencias exactas.',
                        en: 'We did not find exact matches.',
                      ),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      tr(
                        context,
                        es: 'Con el sistema actual, esto funciona mejor con fotos iguales o muy parecidas. Más adelante puedes mejorarlo con búsqueda visual por IA.',
                        en: 'With the current system, this works best with identical or very similar photos. Later you can improve it with AI visual search.',
                      ),
                    ),
                  ],
                ),
              ),
            )
          else if (_matches.isNotEmpty) ...[
            Text(
              tr(
                context,
                es: 'Coincidencias encontradas',
                en: 'Matches found',
              ),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ..._matches.map((match) => _MatchCard(match: match)),
          ] else
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  tr(
                    context,
                    es: 'Usa la cámara o la galería para buscar un objeto ya guardado.',
                    en: 'Use the camera or gallery to search for a saved item.',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MatchCard extends StatelessWidget {
  final PotentialDuplicateModel match;

  const _MatchCard({
    required this.match,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ItemDetailPage(itemId: match.itemId),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: 88,
                  height: 88,
                  child: match.primaryPhotoPath != null
                      ? Image.file(
                          File(match.primaryPhotoPath!),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const ColoredBox(
                            color: Color(0x11000000),
                            child: Icon(Icons.image_not_supported_outlined),
                          ),
                        )
                      : const ColoredBox(
                          color: Color(0x11000000),
                          child: Icon(Icons.image_outlined),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      match.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${tr(context, es: 'Categoría', en: 'Category')}: ${match.categoryName}',
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${tr(context, es: 'Colección', en: 'Collection')}: ${match.collectionName}',
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3E8FF),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        tr(
                          context,
                          es: 'Coincidencia por foto',
                          en: 'Photo match',
                        ),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}
